using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleMovement : MonoBehaviour
{
    public float moveSpeed = 2f;
    public float moveDistance = 3f;

    private Vector2 startPosition;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {

        float newY = Mathf.PingPong(Time.time * moveSpeed, moveDistance);
        transform.position = new Vector2(startPosition.x, startPosition.y + newY);
    }
}

//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class Obstacle : MonoBehaviour
//{
//    public Transform pointA;
//    public Transform pointB;
//    public float moveSpeed = 8f;
//    public float moveDistance = 8f;
//    private Vector2 startPosition; 
//    private Vector2 endPosition;
//    private float journeyLength;
//    private float startTime;

//    void Start()
//    {
//        startPosition = pointA.position;
//        endPosition = pointB.position;
//        journeyLength = Vector2.Distance(startPosition, endPosition);
//        startTime = Time.time;
//    }

//    void Update()
//    {
//        float distanceCovered = (Time.time - startTime) * moveSpeed;
//        float fractionOfJourney = distanceCovered / journeyLength;

//        Vector2 currentPosition = Vector2.Lerp(startPosition, endPosition, Mathf.PingPong(fractionOfJourney, 5));
//        transform.position = currentPosition;


//        if (journeyLength > 0)
//        {
//            startTime = Time.time;
//        }

//    }
//}
