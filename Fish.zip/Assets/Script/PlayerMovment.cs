﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovment : MonoBehaviour
{
    public float moveSpeed = 5f;

    // مفاتيح التحكم
    public KeyCode Up = KeyCode.W;
    public KeyCode Down = KeyCode.S;
    public KeyCode Left = KeyCode.A;
    public KeyCode Right = KeyCode.D;

    private Rigidbody2D rb;
    private Vector2 moveInput;
    private Vector2 startPosition;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        startPosition = rb.position;
    }

    void Update()
    { 
        moveInput = Vector2.zero;

        if (Input.GetKey(Up))
        {
            moveInput.y = 1;
        }
        else if (Input.GetKey(Down))
        {
            moveInput.y = -1;
        }

        if (Input.GetKey(Left))
        {
            moveInput.x = -1;
        }
        else if (Input.GetKey(Right))
        {
            moveInput.x = 1;
        }

       
        moveInput.Normalize(); 
    }

    void FixedUpdate()
    {
        Vector2 moveVelocity = moveInput * moveSpeed;
        rb.MovePosition(rb.position + moveVelocity * Time.fixedDeltaTime);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            
            rb.position = startPosition;
            
        }
    }
}
